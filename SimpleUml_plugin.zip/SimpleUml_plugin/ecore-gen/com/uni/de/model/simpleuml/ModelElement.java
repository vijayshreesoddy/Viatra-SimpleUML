/**
 */
package com.uni.de.model.simpleuml;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Model Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.uni.de.model.simpleuml.ModelElement#getName <em>Name</em>}</li>
 *   <li>{@link com.uni.de.model.simpleuml.ModelElement#getStereotype <em>Stereotype</em>}</li>
 *   <li>{@link com.uni.de.model.simpleuml.ModelElement#getTaggedValue <em>Tagged Value</em>}</li>
 * </ul>
 *
 * @see com.uni.de.model.simpleuml.SimpleumlPackage#getModelElement()
 * @model abstract="true"
 * @generated
 */
public interface ModelElement extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see com.uni.de.model.simpleuml.SimpleumlPackage#getModelElement_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link com.uni.de.model.simpleuml.ModelElement#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Stereotype</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stereotype</em>' attribute list.
	 * @see com.uni.de.model.simpleuml.SimpleumlPackage#getModelElement_Stereotype()
	 * @model ordered="false"
	 * @generated
	 */
	EList<String> getStereotype();

	/**
	 * Returns the value of the '<em><b>Tagged Value</b></em>' containment reference list.
	 * The list contents are of type {@link com.uni.de.model.simpleuml.TaggedValue}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tagged Value</em>' containment reference list.
	 * @see com.uni.de.model.simpleuml.SimpleumlPackage#getModelElement_TaggedValue()
	 * @model containment="true"
	 * @generated
	 */
	EList<TaggedValue> getTaggedValue();

} // ModelElement
