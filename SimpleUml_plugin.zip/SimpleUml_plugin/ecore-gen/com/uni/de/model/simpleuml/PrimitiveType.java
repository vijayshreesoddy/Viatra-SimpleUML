/**
 */
package com.uni.de.model.simpleuml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see com.uni.de.model.simpleuml.SimpleumlPackage#getPrimitiveType()
 * @model
 * @generated
 */
public interface PrimitiveType extends Type {
} // PrimitiveType
