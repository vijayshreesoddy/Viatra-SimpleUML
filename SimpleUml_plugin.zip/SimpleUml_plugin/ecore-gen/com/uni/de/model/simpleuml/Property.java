/**
 */
package com.uni.de.model.simpleuml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Property</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.uni.de.model.simpleuml.Property#getType <em>Type</em>}</li>
 *   <li>{@link com.uni.de.model.simpleuml.Property#getOwner <em>Owner</em>}</li>
 * </ul>
 *
 * @see com.uni.de.model.simpleuml.SimpleumlPackage#getProperty()
 * @model
 * @generated
 */
public interface Property extends ModelElement {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' reference.
	 * @see #setType(Type)
	 * @see com.uni.de.model.simpleuml.SimpleumlPackage#getProperty_Type()
	 * @model required="true"
	 * @generated
	 */
	Type getType();

	/**
	 * Sets the value of the '{@link com.uni.de.model.simpleuml.Property#getType <em>Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' reference.
	 * @see #getType()
	 * @generated
	 */
	void setType(Type value);

	/**
	 * Returns the value of the '<em><b>Owner</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link com.uni.de.model.simpleuml.DataType#getAttributes <em>Attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owner</em>' container reference.
	 * @see #setOwner(DataType)
	 * @see com.uni.de.model.simpleuml.SimpleumlPackage#getProperty_Owner()
	 * @see com.uni.de.model.simpleuml.DataType#getAttributes
	 * @model opposite="attributes" required="true" transient="false"
	 * @generated
	 */
	DataType getOwner();

	/**
	 * Sets the value of the '{@link com.uni.de.model.simpleuml.Property#getOwner <em>Owner</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Owner</em>' container reference.
	 * @see #getOwner()
	 * @generated
	 */
	void setOwner(DataType value);

} // Property
