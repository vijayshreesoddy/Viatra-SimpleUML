/**
 */
package com.uni.de.model.simpleuml;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Package</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.uni.de.model.simpleuml.Package#getOwnedElements <em>Owned Elements</em>}</li>
 * </ul>
 *
 * @see com.uni.de.model.simpleuml.SimpleumlPackage#getPackage()
 * @model
 * @generated
 */
public interface Package extends Classifier, Packageable {
	/**
	 * Returns the value of the '<em><b>Owned Elements</b></em>' containment reference list.
	 * The list contents are of type {@link com.uni.de.model.simpleuml.Packageable}.
	 * It is bidirectional and its opposite is '{@link com.uni.de.model.simpleuml.Packageable#getOwner <em>Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owned Elements</em>' containment reference list.
	 * @see com.uni.de.model.simpleuml.SimpleumlPackage#getPackage_OwnedElements()
	 * @see com.uni.de.model.simpleuml.Packageable#getOwner
	 * @model opposite="owner" containment="true"
	 * @generated
	 */
	EList<Packageable> getOwnedElements();

} // Package
