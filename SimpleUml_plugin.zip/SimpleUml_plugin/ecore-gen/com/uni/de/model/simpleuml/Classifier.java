/**
 */
package com.uni.de.model.simpleuml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Classifier</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see com.uni.de.model.simpleuml.SimpleumlPackage#getClassifier()
 * @model abstract="true"
 * @generated
 */
public interface Classifier extends ModelElement {
} // Classifier
