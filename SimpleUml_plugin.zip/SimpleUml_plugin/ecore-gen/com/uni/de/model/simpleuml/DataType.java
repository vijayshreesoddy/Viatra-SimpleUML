/**
 */
package com.uni.de.model.simpleuml;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Data Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.uni.de.model.simpleuml.DataType#getAttributes <em>Attributes</em>}</li>
 * </ul>
 *
 * @see com.uni.de.model.simpleuml.SimpleumlPackage#getDataType()
 * @model
 * @generated
 */
public interface DataType extends Type {
	/**
	 * Returns the value of the '<em><b>Attributes</b></em>' containment reference list.
	 * The list contents are of type {@link com.uni.de.model.simpleuml.Property}.
	 * It is bidirectional and its opposite is '{@link com.uni.de.model.simpleuml.Property#getOwner <em>Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributes</em>' containment reference list.
	 * @see com.uni.de.model.simpleuml.SimpleumlPackage#getDataType_Attributes()
	 * @see com.uni.de.model.simpleuml.Property#getOwner
	 * @model opposite="owner" containment="true"
	 * @generated
	 */
	EList<Property> getAttributes();

} // DataType
