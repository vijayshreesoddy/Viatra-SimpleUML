/**
 */
package com.uni.de.model.simpleuml.impl;

import com.uni.de.model.simpleuml.Classifier;
import com.uni.de.model.simpleuml.SimpleumlPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Classifier</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class ClassifierImpl extends ModelElementImpl implements Classifier {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ClassifierImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SimpleumlPackage.Literals.CLASSIFIER;
	}

} //ClassifierImpl
