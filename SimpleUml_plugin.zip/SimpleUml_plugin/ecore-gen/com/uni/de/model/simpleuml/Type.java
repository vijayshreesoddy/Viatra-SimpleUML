/**
 */
package com.uni.de.model.simpleuml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see com.uni.de.model.simpleuml.SimpleumlPackage#getType()
 * @model abstract="true"
 * @generated
 */
public interface Type extends Classifier, Packageable {
} // Type
